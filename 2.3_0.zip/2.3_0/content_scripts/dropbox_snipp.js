﻿window.addEventListener("message", function (event) {
    if (event.source != window)
        return;
    if (event.data.type && (event.data.type == "Cloud_File_Blob")) {
        angular.element(document.getElementsByClassName('drop-box')).scope().vm.onAttachmentDrop(event.data.filesList);
    }
});


var options = {
    success: function (files) {
        window.postMessage({ type: "Cloud_Files_Obj", files: files }, "*");
    },
    linkType: "preview", // or "direct"
    multiselect: false, // or true
    folderselect: false, // or true
};
